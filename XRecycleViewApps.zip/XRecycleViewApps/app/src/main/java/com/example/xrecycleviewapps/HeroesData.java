package com.example.xrecycleviewapps;

import java.util.ArrayList;

public class HeroesData {
    public static String[][] data = new String[][]{

            {"Soeharto","kelahirannya yaitu pada tanggal 8 Juni 1921 di Dusun Kemusuk, Desa Argomulyo, Kecamatan Sedayu, Kabupaten Bantul, Provinsi DI Yogyakarta.", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqcpNfhiI0TTFrhD_hP0-gImfwwxsXfg00fOjzaheCDSQ2AuM6qw"
            },
            {"Soekarno"," Blitar, Jawa Timur","http://maritimnews.com/wp-content/uploads/2017/09/sukarno2.jpg"},
    };

    public static ArrayList<Hero> getListData() {
        ArrayList<Hero> list = new ArrayList<>();
        for(String[]aData : data)
        {
            Hero hero =new Hero();
            hero.setName(aData[0]);
            hero.setAsal(aData[1]);
            hero.setPhoto(aData[2]);
            list.add(hero);
        }
        return list;
    }
}
