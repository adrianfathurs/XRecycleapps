package com.example.xrecycleviewapps;

public class Hero {
    public  String name,dari,photo;

    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }

    
    public void setAsal(String nama) {
        this.dari = nama;
    }
    
    public  String getAsal() {

        return dari;
    }

 

    public  String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
